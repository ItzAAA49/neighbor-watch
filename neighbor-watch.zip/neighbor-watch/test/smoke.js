const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const vm = require('node:vm');

const root = path.resolve(__dirname, '..');
const dataContext = { window: {} };
vm.createContext(dataContext);
for (const file of ['public/js/data.js', 'public/js/face.js']) {
  vm.runInContext(fs.readFileSync(path.join(root, file), 'utf8'), dataContext, { filename: file });
}
const data = dataContext.window.NW_DATA;
const face = dataContext.window.NW_FACE;
assert.equal(data.normal.length, 20, 'normal resident roster');
assert.equal(data.nightmare.length, 20, 'nightmare resident roster');
assert.equal(data.posterNames.length, 32, 'poster roster');
assert.equal(data.quiz.length, 5, 'Chester quiz');
for (const roster of [data.normal, data.nightmare]) {
  assert.equal(new Set(roster.map((p) => p.name)).size, roster.length, 'resident names are unique');
  for (const resident of roster) {
    assert.match(resident.id, /^\d{12}$/, `${resident.name} ID`);
    assert.match(resident.phone, /^\d{4}$/, `${resident.name} phone`);
    const svg = face.portrait(resident, { night: roster === data.nightmare });
    assert.ok(svg.startsWith('<svg') && svg.endsWith('</svg>'), `${resident.name} portrait`);
  }
}

class Element {
  constructor(id = '') {
    this.id = id; this.innerHTML = ''; this.textContent = ''; this.hidden = false;
    this.disabled = false; this.value = ''; this.style = {}; this.dataset = {};
    this.className = ''; this.children = []; this.listeners = {}; this.onclick = null;
    this.classList = { add() {}, remove() {}, toggle() {} };
  }
  addEventListener(type, fn) { (this.listeners[type] ||= []).push(fn); }
  querySelectorAll() { return []; }
  querySelector() { return new Element(); }
  appendChild(node) { this.children.push(node); }
  setPointerCapture() {}
}
const ids = `modal-content modal-backdrop modal-window modal-close dial-pointer mode-label day-label visitor-counter time-label today-list checklist-items check-count check-progress-bar visitor-empty visitor-display visitor-name visitor-role visitor-face visitor-line visitor-kind window-status id-document form-document id-doc-name form-doc-name ask-button next-line calendar-grid alarm-lamp emergency-button phone-number phone-dial dial-clear dial-call admit-button reject-button report-button folder-button pause-button pause-overlay resume-button visitor-dialog toast window-section window-frame chester-badge clown-flyer decision-panel`.split(' ');
const elements = Object.fromEntries(ids.map((id) => [id, new Element(id)]));
const document = {
  getElementById(id) { return (elements[id] ||= new Element(id)); },
  querySelectorAll() { return []; },
  addEventListener() {},
  createElement(tag) { return new Element(tag); },
  body: new Element('body'),
};
const storage = {};
const localStorage = {
  getItem(key) { return storage[key] ?? null; },
  setItem(key, value) { storage[key] = String(value); },
  removeItem(key) { delete storage[key]; },
};
const Neighbor = {
  active() { return null; }, writeActive(value) { storage.active = JSON.stringify(value); },
  getSave() { return { posters: [], achievements: [], records: [], stats: {}, campaign: {} }; },
  setSave() {}, toast() {}, RESULT: 'result', ACTIVE: 'active',
};
function boot(mode) {
  const localElements = Object.fromEntries(ids.map((id) => [id, new Element(id)]));
  const localDocument = {
    getElementById(id) { return (localElements[id] ||= new Element(id)); },
    querySelectorAll() { return []; }, addEventListener() {},
    createElement(tag) { return new Element(tag); }, body: new Element('body'),
  };
  const localStorageData = {};
  const localStorageMock = { getItem(k) { return localStorageData[k] ?? null; }, setItem(k,v) { localStorageData[k]=String(v); }, removeItem(k) { delete localStorageData[k]; } };
  const neighborMock = { active(){return null;}, writeActive(v){localStorageData.active=JSON.stringify(v);}, getSave(){return {posters:[],achievements:[],records:[],stats:{},campaign:{}};}, setSave(){}, toast(){}, RESULT:'result', ACTIVE:'active' };
  const context = { window:{}, document:localDocument, localStorage:localStorageMock, Neighbor:neighborMock, NW_DATA:data, NW_FACE:face, URLSearchParams, location:{search:'?mode='+mode,href:''}, Math, Date, crypto:require('node:crypto').webcrypto, setTimeout(){}, clearTimeout(){}, setInterval(){return 1;}, clearInterval(){}, console };
  vm.createContext(context);
  vm.runInContext(fs.readFileSync(path.join(root, 'public/js/game.js'), 'utf8'), context, { timeout:5000, filename:'game.js' });
  return { elements:localElements, stored:localStorageData };
}
const campaign = boot('campaign');
const activeGame = JSON.parse(campaign.stored.active);
assert.equal(activeGame.mode, 'campaign');
assert.equal(activeGame.visitors.length, 6, 'campaign day one visitor count');
assert.ok(activeGame.todayList.length >= 4 && activeGame.todayList.length <= 9, 'today list contains 4–9 entries');
assert.ok(campaign.elements['visitor-face'].innerHTML.includes('<svg'), 'visitor portrait renders');
const nightmare = boot('nightmare');
assert.equal(JSON.parse(nightmare.stored.active).visitors.length, 10, 'nightmare visitor count');
const cards = boot('cards');
assert.ok(cards.elements['modal-content'].innerHTML.includes('カード対決'), 'card mode opens');
console.log('Smoke tests passed: resident data, IDs, phones, 40 SVG portraits, campaign, nightmare, and card-mode boot.');
