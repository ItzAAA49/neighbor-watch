(() => {
  const $ = id => document.getElementById(id);
  const qs = new URLSearchParams(location.search);
  const labels = {campaign:'キャンペーン',tutorial:'チュートリアル',arcade:'アーケード',nightmare:'ナイトメア',custom:'カスタム',cards:'カードゲーム'};
  let g = Neighbor.active();
  if (qs.has('mode') && g && g.mode !== qs.get('mode')) g = null;
  if (!g) { g={mode:qs.get('mode')||'campaign',day:1,dead:[],createdAt:Date.now(),seed:Date.now(),visitorIndex:0,visitors:[],checklist:{},actions:[],score:0,captures:0,kills:0,admitted:0,minorMistakes:0,errors:0,reportErrors:0,chesterDone:false,campaignStats:{admittedNames:[],reportedNames:[]}}; Neighbor.writeActive(g); }
  let current=null, phone='----', emergency=false, residentPage=0, questionQueue=[], soundContext=null, dailyBriefShown=false, quizAsked=false, clockInterval=null;
  const rand=()=>{g.seed=(Math.imul(g.seed,1664525)+1013904223)>>>0;return g.seed/4294967296;};
  const pick=arr=>arr[Math.floor(rand()*arr.length)];
  const esc=s=>NW_FACE.esc(s);
  const todayISO=()=>new Date().toISOString().slice(0,10);
  const isCampaign=()=>g.mode==='campaign';
  const isNight=()=>g.mode==='nightmare';
  const isTutorial=()=>g.mode==='tutorial';
  const visitorsTarget=()=>g.mode==='campaign'?[6,8,10,11,12][Math.max(0,Math.min(4,(g.day||1)-1))]:(g.mode==='tutorial'?4:10);
  const doppelRate=()=>g.mode==='campaign'?[.25,.35,.45,.5,.55][Math.max(0,Math.min(4,(g.day||1)-1))]:(isNight()?.6:(g.mode==='tutorial'?.25:.5));
  const people=()=>isNight()?NW_DATA.nightmare:NW_DATA.normal;
  function sound(kind='click'){try{soundContext=soundContext||new (window.AudioContext||window.webkitAudioContext)();if(soundContext.state==='suspended')soundContext.resume();const osc=soundContext.createOscillator(),gain=soundContext.createGain();osc.connect(gain);gain.connect(soundContext.destination);const now=soundContext.currentTime;const freqs={click:450,ring:290,alert:180,success:620,wrong:110,dial:330,door:240};osc.type=kind==='alert'?'sawtooth':'triangle';osc.frequency.setValueAtTime(freqs[kind]||400,now);osc.frequency.exponentialRampToValueAtTime((freqs[kind]||400)*.72,now+.12);gain.gain.setValueAtTime(.0001,now);gain.gain.exponentialRampToValueAtTime(.055,now+.015);gain.gain.exponentialRampToValueAtTime(.0001,now+.2);osc.start(now);osc.stop(now+.21);}catch{}}
  function store(){Neighbor.writeActive(g);}
  function notify(msg,type='click'){Neighbor.toast(msg);sound(type);}
  function showModal(html){$('modal-content').innerHTML=html;$('modal-backdrop').hidden=false;$('modal-window').scrollTop=0;}
  function closeModal(){$('modal-backdrop').hidden=true;$('modal-content').innerHTML='';}
  $('modal-close').addEventListener('click',closeModal);$('modal-backdrop').addEventListener('click',e=>{if(e.target===$('modal-backdrop'))closeModal();});
  function buildFaceTags(person,defect){let tags=[...(person.tags||[])];if(defect==='appearance'){const swaps=[['moleLeft','moleRight'],['hat'],['mustache'],['glasses'],['bigBrow'],['longNeck'],['freckles'],['pointNose'],['curlLeft','curlRight']];const choose=pick(swaps);for(const t of choose){if(tags.includes(t))tags=tags.filter(x=>x!==t);else tags.push(t);} }return tags;}
  function buildVisitors(){
    g.startedAt=Date.now();g.timeLimit=visitorsTarget()*60000;g.timeBonusAwarded=false;
    const pool=people().filter(p=>!g.dead.includes(p.name));
    if(isCampaign())g.campaignStats=g.campaignStats||{admittedNames:[],reportedNames:[],visitorCount:0,doppelVisitors:0,admittedVisitors:0,admittedDoppels:0,capturedDoppels:0,rejectedResidents:0,humanKilled:0,seenNames:[]};
    const seenCampaign=new Set(g.campaignStats?.seenNames||[]);
    const count=visitorsTarget();const list=[];const used=[];
    for(let i=0;i<count;i++){
      const unused=pool.filter(person=>!used.includes(person.name));
      const unseen=isCampaign()?unused.filter(person=>!seenCampaign.has(person.name)):unused;
      let p=pick(unseen.length?unseen:(unused.length?unused:pool));used.push(p.name);if(isCampaign())seenCampaign.add(p.name);
      let truth=isTutorial()?i!==2:rand()>=doppelRate();
      let vip=null;
      if(!isNight()&&g.mode!=='tutorial'&&i===count-1&&g.day===1&&rand()<.4){vip='42';truth=false;}
      if(!isNight()&&g.mode!=='tutorial'&&i===count-2&&g.day===2&&rand()<.2){vip='Peach';truth=false;}
      if(isNight()&&i===count-1&&rand()<.35){vip=pick(['42','Peach','Nurse']);truth=true;}
      const issueTypes=['appearance','id','form','combined'];let defects=[];
      if(!truth){defects=[pick(issueTypes)];if(defects[0]==='combined'&&rand()<.5)defects.push('appearance');}
      if(isTutorial()&&i===2)defects=['appearance'];
      if(truth&&rand()<.1)defects=['missing-hat']; // harmless anomaly is intentionally treated as non-fatal unless unsupported
      const listed=rand()<.73;
      const doc=p;
      let visitor={person:p,residentName:p.name,truth,defects,listed,faceTags:buildFaceTags(p,defects.includes('appearance')?'appearance':null),vip,redHanded:!truth&&['Albertsky Peachman','Alf Cappuccin','Dr. W. Afton','Elenois Sverchzt','Francis Mosses','Izaack Gauss','Lois Stilnsky','Margarette Bubbles','Mia Stone','Rafttellyn Cappuccin','Robertsky Peachman','Roman Stilnsky','Selenne Sverchzt','Steven Rudboys'].includes(p.name),appearanceIssue:defects.includes('appearance'),idIssue:defects.includes('id')||defects.includes('combined'),formIssue:defects.includes('form')||defects.includes('combined'),idData:{...doc},formData:{...doc},idMissing:false,formMissing:false,dialog:'こんにちは。戻ってきました。'};
      if(defects.includes('id')||defects.includes('combined')){const mode=Math.floor(rand()*4);if(mode===0)visitor.idData.id=visitor.idData.id.slice(0,11)+'8';if(mode===1)visitor.idData.name=visitor.idData.name.replace('a','e');if(mode===2)visitor.idData.expiry='01/54';if(mode===3)visitor.idData.stamp=false;}
      if(defects.includes('form')||defects.includes('combined')){const mode=Math.floor(rand()*4);if(mode===0)visitor.formData.room='F04-09';if(mode===1)visitor.formData.job='星の管理人';if(mode===2)visitor.formData.reason='I return because yesterday future.';if(mode===3)visitor.formData.approved=false;}
      if(truth&&rand()<.035){visitor.idMissing=true;visitor.idIssue=true;}if(truth&&rand()<.025){visitor.formMissing=true;visitor.formIssue=true;}
      if(vip==='42'){visitor.person={...p,name:'42',id:'424242424242',job:'—',features:'顔に巨大な42の渦',tags:['42Face'],room:p.room,phone:p.phone,roommate:p.roommate};visitor.faceTags=['42Face'];visitor.idData={...visitor.person,id:'424242424242',stamp:true};visitor.formData={...visitor.person,job:'42',reason:'42'};visitor.appearanceIssue=true;visitor.idIssue=true;visitor.formIssue=true;}
      if(vip==='Peach'){visitor.person={...p,name:'Peach',job:'—',features:'大きく開いた口、出っ歯、斜めの充血した目',tags:['bigSmile','bigTeeth','redEyes']};visitor.faceTags=visitor.person.tags;visitor.appearanceIssue=true;visitor.idData={...p,name:'Peach'};visitor.formData={...p,name:'Peach'};}
      if(vip==='Nurse'){visitor.person={...p,name:'Xuchilbara Lobsel Vith',job:'特別来訪者',features:'包帯を巻いた静かな人物',tags:['longHair','tiredEyes']};visitor.faceTags=visitor.person.tags;visitor.idData={...p,name:visitor.person.name};visitor.formData={...p,name:visitor.person.name};}
      list.push(visitor);
    }
    if(isCampaign()){
      g.campaignStats.seenNames=[...seenCampaign];
      g.campaignStats.visitorCount=(g.campaignStats.visitorCount||0)+list.length;
      g.campaignStats.doppelVisitors=(g.campaignStats.doppelVisitors||0)+list.filter(v=>!v.truth).length;
    }
    // A guaranteed poster-type visitor on campaign days: a visibly distinct but original variation.
    if(g.mode==='campaign'&&list.length){let target=list.find(v=>!v.truth);if(!target){target=list[0];target.truth=false;target.defects=['appearance'];target.appearanceIssue=true;g.campaignStats.doppelVisitors=(g.campaignStats.doppelVisitors||0)+1;target.faceTags=buildFaceTags(target.person,'appearance');}target.defects=[...new Set([...(target.defects||[]),'appearance'])];target.appearanceIssue=true;target.posterIndex=Math.floor(rand()*NW_DATA.posterNames.length);target.faceTags=[...(target.faceTags||[]),'extraEyes'];target.poster=true;}
    g.visitors=list;g.visitorIndex=0;g.checklist={};g.actions=[];g.currentEvent=null;store();
    const scheduleCount=Math.max(4,Math.min(9,Math.floor(4+rand()*6)));
    const candidateNames=list.map(v=>v.residentName);
    for(let i=candidateNames.length-1;i>0;i--){const j=Math.floor(rand()*(i+1));[candidateNames[i],candidateNames[j]]=[candidateNames[j],candidateNames[i]];}
    const chosen=candidateNames.slice(0,Math.min(scheduleCount,candidateNames.length));
    const extras=pool.filter(p=>!chosen.includes(p.name));
    while(chosen.length<scheduleCount&&extras.length){const index=Math.floor(rand()*extras.length);chosen.push(extras.splice(index,1)[0].name);}
    g.todayList=chosen.map(name=>{const p=pool.find(x=>x.name===name);return p?{name:p.name,room:p.room}:null;}).filter(Boolean);
    list.forEach(v=>{v.listed=chosen.includes(v.residentName);});
    store();
  }
  function updateClock(){const limit=g.timeLimit||visitorsTarget()*60000;const elapsed=Date.now()-(g.startedAt||Date.now());const left=Math.max(0,limit-elapsed);const minutes=Math.floor(left/60000),seconds=Math.floor((left%60000)/1000);$('time-label').textContent=`残り ${String(minutes).padStart(2,'0')}:${String(seconds).padStart(2,'0')}`;$('time-label').classList.toggle('time-low',left<60000);if(left===0)$('time-label').textContent='時間ボーナス終了';}
  function startClock(){if(!g.startedAt)g.startedAt=Date.now();if(!g.timeLimit)g.timeLimit=visitorsTarget()*60000;updateClock();if(clockInterval)clearInterval(clockInterval);clockInterval=setInterval(updateClock,1000);}
  function setUpHeader(){ $('mode-label').textContent=labels[g.mode]||'勤務';$('day-label').textContent=`1955年 2月 ${g.day||1}日`;$('visitor-counter').textContent=`来訪者 ${Math.min(g.visitorIndex+1,visitorsTarget())} / ${visitorsTarget()}`;document.querySelectorAll('.calendar-grid i').forEach(n=>n.classList.toggle('active',n.textContent.trim()===String(g.day||1))); }
  function initChecklist(){const box=$('checklist-items');box.innerHTML='';[['appearance','外見'],['id','IDカード'],['form','入居申請書'],['list','今日のリスト']].forEach(([key,label])=>{let row=document.createElement('div');row.className='check-row';row.innerHTML=`<span>${label}</span><button data-key="${key}" data-val="yes">YES</button><button data-key="${key}" data-val="no">NO</button>`;row.querySelectorAll('button').forEach(b=>b.addEventListener('click',()=>setCheck(key,b.dataset.val)));box.appendChild(row);});updateChecklistUI();}
  function setCheck(key,val){if(!current)return;g.checklist[key]=val;store();updateChecklistUI();sound('click');}
  function updateChecklistUI(){const keys=['appearance','id','form','list'];let done=keys.filter(k=>g.checklist[k]);$('check-count').textContent=`${done.length} / 4 完了`; $('check-progress-bar').style.width=(done.length/4*100)+'%';document.querySelectorAll('.check-row button').forEach(b=>{const selected=g.checklist[b.dataset.key]===b.dataset.val;b.classList.toggle('selected',selected);b.classList.toggle(b.dataset.val,selected);});const enabled=done.length===4&&!!current;$('decision-panel').classList.toggle('ready',done.length===4);$('admit-button').disabled=!enabled||emergency;$('reject-button').disabled=!enabled||emergency;$('report-button').disabled=!enabled||!emergency||phone!=='3312';}
  function renderToday(){const box=$('today-list');box.innerHTML='';(g.todayList||[]).forEach(item=>{const div=document.createElement('div');div.className='today-item';div.innerHTML=`<b>${esc(item.name)}</b><small>${esc(item.room)}</small>`;box.appendChild(div);});if(!box.children.length)box.innerHTML='<span class="today-item">予定は登録されていません</span>';}
  function renderVisitor(){current=g.visitors[g.visitorIndex]||null;setUpHeader();initChecklist();if(!current){finishShift();return;}
    $('visitor-empty').hidden=true;$('visitor-display').hidden=false;$('visitor-name').textContent=current.person.name;$('visitor-role').textContent=current.person.job;$('visitor-face').innerHTML=NW_FACE.portrait({...current.person,tags:current.faceTags||current.person.tags},{night:isNight()});$('visitor-line').textContent=current.dialog;$('visitor-kind').textContent=current.vip?'SPECIAL VISITOR':(current.truth?'RESIDENT':'VISITOR');$('window-status').textContent='審査中';$('id-document').disabled=false;$('form-document').disabled=false;$('id-doc-name').textContent=current.idMissing?'未提出':current.idData.name;$('form-doc-name').textContent=current.formMissing?'未提出':current.formData.name;$('ask-button').disabled=false;$('next-line').disabled=false;updateChecklistUI();
    if(isTutorial())$('visitor-line').textContent='研修中です。顔、書類、名簿、電話の順に確認してください。';
    if(current.vip==='42')$('visitor-line').textContent='42';else if(current.vip==='Peach')$('visitor-line').textContent='……';
    sound('ring');
  }
  function resetView(){current=null;$('visitor-empty').hidden=false;$('visitor-display').hidden=true;$('visitor-line').textContent='次の来訪者をお待ちください。';$('visitor-kind').textContent='NO VISITOR';$('window-status').textContent='待機中';$('id-document').disabled=true;$('form-document').disabled=true;$('ask-button').disabled=true;$('next-line').disabled=true;['admit-button','reject-button','report-button'].forEach(id=>$(id).disabled=true);}
  function showDocument(which){if(!current)return;const d=which==='id'?current.idData:current.formData;const missing=which==='id'?current.idMissing:current.formMissing;const title=which==='id'?'IDカード / IDENTIFICATION':'入居申請書 / RESIDENCE APPLICATION';const stamp=which==='id'?(d.stamp===false?'印章なし':'D.D.D. APPROVED'):(d.approved===false?'承認印なし':'APPROVED / D.D.D.');let fields=which==='id'?[['氏名',d.name],['ID番号',d.id],['有効期限',d.expiry||'08/57'],['写真',d.name+' の白黒写真'],['ロゴ・スタンプ',stamp]]:[['氏名',d.name],['部屋番号',d.room],['職業',d.job],['帰宅理由',d.reason||'仕事から帰宅しました。'],['写真',d.name+' の白黒写真'],['承認',stamp]];
    showModal(`<h2 class="modal-title">${title}</h2>${missing?'<p class="modal-note">この書類は提出されていません。</p>':''}<div class="document-preview"><div class="classified">DOPPELGÄNGER DETECTION DEPARTMENT</div><div class="doc-face">${NW_FACE.portrait({...current.person,tags:current.person.tags},{})}</div><div class="doc-grid">${fields.map(([k,v])=>`<div class="doc-field"><small>${k}</small><b>${esc(v)}</b></div>`).join('')}</div></div><p class="modal-note">名簿フォルダーの正しい情報と照合してください。書類の体裁だけで真偽を判断しないこと。</p><div class="modal-actions"><button class="button" id="doc-close">閉じる</button></div>`);$('doc-close').onclick=closeModal;}
  function openFolder(){const pool=people();residentPage=(residentPage+pool.length)%pool.length;renderFolder();}
  function renderFolder(){const pool=people();let p=pool[residentPage];showModal(`<h2 class="modal-title">住人名簿 / RESIDENT DIRECTORY</h2><div class="resident-profile"><div class="resident-photo">${NW_FACE.portrait(p,{night:isNight()})}</div><div class="resident-info"><h3>${esc(p.name)}</h3><p><small>ID NUMBER</small>${esc(p.id)}</p><p><small>ROOM / TEL</small>${esc(p.room)} / ${esc(p.phone)}</p><p><small>OCCUPATION</small>${esc(p.job)}</p><p><small>HOUSEHOLD</small>${esc(p.roommate)}</p><p><small>APPEARANCE</small>${esc(p.features)}</p></div></div><div class="resident-nav"><button id="resident-prev">◂ 前の住人</button><span class="mono">${residentPage+1} / ${pool.length}</span><button id="resident-next">次の住人 ▸</button></div><p class="modal-note">この名簿は唯一の100%正しい情報源です。外見は服装ではなく顔の特徴で照合します。</p>`);$('resident-prev').onclick=()=>{residentPage=(residentPage-1+pool.length)%pool.length;renderFolder();};$('resident-next').onclick=()=>{residentPage=(residentPage+1)%pool.length;renderFolder();};}
  function askQuestions(){if(!current)return;showModal(`<h2 class="modal-title">来訪者に質問する</h2><p class="modal-note">不自然な点を選び、説明を求めてください。</p><div class="question-list"><button data-q="face">顔や外見について質問する</button><button data-q="papers">書類について質問する</button><button data-q="list">今日の予定について質問する</button><button data-q="reason">帰宅理由について質問する</button></div>`);document.querySelectorAll('[data-q]').forEach(b=>b.onclick=()=>questionAnswer(b.dataset.q));}
  function questionAnswer(type){let answer='特に問題はありません。いつも通りです。';if(current.truth){answer=type==='list'&&!current.listed?'急に予定が変わったんです。電話で確認しても構いません。':'何か問題がありますか？私はここの住人です。';}else if(current.redHanded){answer=type==='face'&&current.appearanceIssue?'ああ、顔のことですか。新しい治療を受けたんです。':'そんな質問をする必要がありますか？早く中へ入れてください。';if(type==='face'){answer+=' ……何を見ているんです？';}}
    if(current.vip==='42')answer='42';if(current.vip==='Peach')answer='……';$('visitor-line').textContent=answer;closeModal();notify('返答を記録しました。');if(!current.truth&&current.redHanded&&type==='face'&&current.appearanceIssue){showModal(`<h2 class="modal-title">不自然な反応</h2><p class="modal-note">質問への反応が急変しました。来訪者の正体に疑いがあります。</p><div class="modal-actions"><button class="button" id="reveal-close">窓口へ戻る</button></div>`);$('reveal-close').onclick=closeModal;}
  }
  function ringPhone(){if(phone.length!==4){notify('4桁の番号を入力してください。','wrong');return;}if(phone==='3312'){if(!emergency){notify('先に緊急ボタンを押してください。','wrong');return;}if(!current){notify('通報対象の来訪者がいません。','wrong');return;}reportVisitor();return;}if(phone==='6666'){if(g.mode==='campaign'||g.mode==='arcade'){notify('不明な番号です。回線が切れました。','wrong');return;}notify('回線の向こうで短い笑い声がします。','alert');return;}const resident=people().find(p=>p.phone===phone);if(!resident){notify('ツー……応答がありません。','wrong');return;}let related=current?.person?.room===resident.room;let response;if(current&&related){if(current.truth){response=resident.roommate==='一人暮らし'?'呼び出し音が3回。応答はなく、ツー音に変わりました。':'同居人です。本人はまだ帰宅していないと言っています。';}else{response=resident.roommate==='一人暮らし'?'電話口から本人の声がします。「今日は誰も帰ってきていないはずです」':'同居人が応答しました。「本人は家にいます。来客の予定はありません」';}}else response='部屋の電話が鳴っています。窓口の人物とは関係がないようです。';
    $('visitor-line').textContent='電話確認：'+response;g.phoneLog=g.phoneLog||[];g.phoneLog.push({number:phone,response});store();notify(response,'dial');if(current&&related&&current.truth&&Math.random()<.1)g.phoneVerified=true;
  }
  function setPhone(value){phone=value.slice(0,4);$('phone-number').textContent=phone.padEnd(4,'-');updateChecklistUI();sound('dial');}
  function pressEmergency(){emergency=!emergency;$('alarm-lamp').classList.toggle('active',emergency);$('emergency-button').classList.toggle('pressed',emergency);$('window-section').classList.toggle('alert-shutter',emergency);$('window-status').textContent=emergency?'緊急回線待機':'審査中';['id-document','form-document','folder-button','ask-button','next-line'].forEach(id=>$(id).disabled=emergency||!current);document.querySelectorAll('.check-row button').forEach(b=>b.disabled=emergency);updateChecklistUI();if(emergency){notify('緊急回線を起動しました。3312へ発信してください。','alert');}else notify('緊急回線を解除しました。');}
  function expectedChecklist(){return {appearance:!current.appearanceIssue,id:!current.idIssue&&!current.idMissing,form:!current.formIssue&&!current.formMissing,list:!!current.listed};}
  function evaluateChecklist(){const expected=expectedChecklist();let correct=0;for(const key of Object.keys(expected)){const chosen=g.checklist[key];if((chosen==='yes')===expected[key])correct++;}return {expected,correct,errors:4-correct};}
  function logAction(action,detail){g.actions.push({action,detail,person:current?.person?.name||'不明'});store();}
  function addPoster(){if(current?.posterIndex!==undefined){const s=Neighbor.getSave();if(!s.posters.includes(current.posterIndex))s.posters.push(current.posterIndex);Neighbor.setSave(s);}}
  function decide(type){if(!current)return;const check=evaluateChecklist();g.errors+=check.errors;g.minorMistakes+=check.errors;g.score+=check.correct*25;const truth=current.truth;let detail='';
    if(isCampaign()){
      const stats=g.campaignStats=g.campaignStats||{admittedNames:[],reportedNames:[],visitorCount:0,doppelVisitors:0,admittedVisitors:0,admittedDoppels:0,capturedDoppels:0,rejectedResidents:0,humanKilled:0};
      if(type==='admit'){stats.admittedVisitors=(stats.admittedVisitors||0)+1;if(!truth)stats.admittedDoppels=(stats.admittedDoppels||0)+1;}
      if(type==='reject'&&truth)stats.rejectedResidents=(stats.rejectedResidents||0)+1;
      if(type==='report'&&truth)stats.humanKilled=(stats.humanKilled||0)+1;
      if(type==='report'&&!truth)stats.capturedDoppels=(stats.capturedDoppels||0)+1;
    }
    if(type==='admit'){
      if(truth||current.vip==='Nurse'||(isNight()&&['42','Peach'].includes(current.vip))){g.score+=25;detail=`${current.person.name} の入室を許可。`;notify('入室許可。ドアが開きました。','door');}
      else {g.admitted++;if(isCampaign()){g.campaignStats=g.campaignStats||{admittedNames:[],reportedNames:[]};g.campaignStats.admittedNames.push(current.person.name);}g.errors++;if(!isTutorial()){g.score=0;g.fatalAdmission=true;}detail=`${current.person.name} を誤って入室させた。`;notify(isNight()?'侵入を確認。非常事態です。':'入室後に異常反応。重大なミスです。','alert');if(isNight()){finishShift(true);return;}}
    } else if(type==='reject'){
      if(truth){g.minorMistakes++;g.score-=50;detail=`本物の ${current.person.name} を拒否。`;notify('本物の住人を拒否しました。','wrong');}
      else {g.score+=50;detail=`${current.person.name} の入室を拒否。`;notify('入室を拒否しました。','success');}
    } else if(type==='report'){
      if(truth){if(isCampaign()){g.campaignStats=g.campaignStats||{admittedNames:[],reportedNames:[]};g.campaignStats.reportedNames.push(current.person.name);}if(!isTutorial()){g.kills++;g.reportErrors++;g.score-=200;g.minorMistakes+=2;}detail=`本物の ${current.person.name} を誤通報。`;if(isCampaign())g.dead.push(current.person.name);notify('誤通報。住人が保護対象から外れました。','wrong');if(isNight()){if(g.reportErrors>=2){g.entityDeath=true;finishShift(true);return;}else{g.entityAppeared=true;showEntityWarning();}}}
      else {g.captures++;g.score+=200;detail=`${current.person.name} をD.D.D.が捕獲。`;addPoster();notify('ドッペルゲンガーを捕獲しました。','success');}
    }
    logAction(type,detail);g.lastDetail=detail;
    if(current.vip==='Chester'){};
    emergency=false;$('alarm-lamp').classList.remove('active');$('emergency-button').classList.remove('pressed');$('window-section').classList.remove('alert-shutter');$('window-frame').classList.add('door-opening');setTimeout(()=>$('window-frame').classList.remove('door-opening'),420);setPhone('----');store();
    g.visitorIndex++;current=null;resetView();if(g.visitorIndex>=g.visitors.length){finishShift();}else renderVisitor();
  }
  function showEntityWarning(){showModal(`<h2 class="modal-title">異常な応答</h2><p class="modal-note">電話回線から紫色の影が窓の向こうに現れ、しばらくあなたを見つめています。回線は不安定です。これ以上の誤通報は避けてください。</p><div class="modal-actions"><button class="button" id="entity-close">確認</button></div>`);$('entity-close').onclick=closeModal;}
  function reportVisitor(){if(!current){notify('通報する来訪者がいません。');return;}if(Object.keys(g.checklist).length<4){notify('チェックリストを完了してください。','wrong');return;}decide('report');}
  function showChester(){if(quizAsked||g.mode!=='campaign'||g.chesterDone)return;quizAsked=true;const index=Math.max(0,(g.day||1)-1),answer=NW_DATA.quiz[index];showModal(`<h2 class="modal-title">チェスター・タイトーの訪問</h2><p class="modal-note">「やあ、門番さん。ちょっとした質問だ。答えが分かるかな？」</p><p class="modal-note"><b>第${index+1}問：${index===0?'1979年に関係する数字は？':index===1?'5日間を秒にすると？':index===2?'次の数字を確認せよ。':index===3?'2の29乗はいくつ？':'最後の数字を答えてくれ。'}</b></p><input id="chester-answer" class="quiz-input" inputmode="numeric" placeholder="答えを入力"><div class="modal-actions"><button id="chester-skip" class="button button-dark">あとで</button><button id="chester-submit" class="button">回答する</button></div>`);$('chester-skip').onclick=()=>{g.chesterDone=true;store();closeModal();};$('chester-submit').onclick=()=>{const value=Number($('chester-answer').value);if(value===answer){g.chesterDone=true;g.chesterCorrect=(g.chesterCorrect||0)+1;const s=Neighbor.getSave();if(g.chesterCorrect>=5){s.chesterBadge=true;if(!s.achievements.includes('chester'))s.achievements.push('chester');Neighbor.setSave(s);$('chester-badge').hidden=false;}notify('正解です。チェスターが満足そうにうなずきました。','success');}else notify('違うようです。チェスターは肩をすくめました。','wrong');g.chesterDone=true;store();closeModal();};}
  function showClown(){if(g.mode!=='campaign'||g.clownSeen||(g.day<5&&!randChance(.45)))return;g.clownSeen=true;$('clown-flyer').hidden=false;store();notify('ピエロの男が「UNLIKELY」と書かれたチラシを机に置きました。');}
  function randChance(n){return Math.random()<n;}
  function startCards(){
    const deck=['2','3','4','5','6','7','8','9','10','J','Q','K','A'];
    let player=[],cpu=[],pile=0,round=1,playerWins=0,cpuWins=0;
    const drawCard=()=>pick(deck);
    const resetRound=()=>{player=Array.from({length:7},drawCard);cpu=Array.from({length:7},drawCard);pile=0;};
    const wild=c=>['J','Q','K','A'].includes(c);
    const canPlay=c=>!pile||wild(c)||Number(c)>pile;
    function finishMatch(){
      closeModal();
      const result=playerWins>cpuWins?'あなたの勝利です。クラウンは静かにカードを片付けました。':playerWins<cpuWins?'クラウンの勝利です。対決はここで終了しました。':'3ラウンドは引き分けです。';
      showModal(`<h2 class="modal-title">カード対決 — 結果</h2><p class="modal-note">${result}</p><p class="card-score">あなた ${playerWins} — ${cpuWins} クラウン</p><div class="modal-actions"><button class="button" id="card-finish">閉じる</button></div>`);
      $('card-finish').onclick=closeModal;
    }
    function endRound(){
      if(player.length&&cpu.length)return false;
      if(!player.length)playerWins++;else cpuWins++;
      if(round>=3){finishMatch();return true;}
      round++;resetRound();render();return true;
    }
    function render(){
      const hasMove=player.some(canPlay);
      showModal(`<h2 class="modal-title">ナイトメア・クラウン — カード対決</h2><p class="modal-note">3ラウンド制。場の数字より大きいカード、またはJ/Q/K/Aを出します。出せるカードがないときは山札から1枚引きます。</p><div class="card-table"><div class="card-opponent">クラウンの手札：${cpu.length}枚</div><div class="card-score">ラウンド ${round} / 3　あなた ${playerWins} — ${cpuWins} クラウン</div><div class="card-pile">場のカード <b>${pile||'—'}</b></div><p>あなたの手札</p><div class="playing-hand">${player.map((c,i)=>`<button data-card="${i}" class="playing-card">${c}</button>`).join('')}</div><div class="modal-actions"><button id="card-draw" class="button button-dark" ${hasMove?'disabled':''}>山札から1枚引く</button></div><p id="card-status" class="modal-note">カードを選んでください。</p></div>`);
      document.querySelectorAll('[data-card]').forEach(b=>b.onclick=()=>play(Number(b.dataset.card)));
      $('card-draw').onclick=draw;
    }
    function cpuTurn(){
      const idx=cpu.findIndex(canPlay);
      if(idx<0){cpu.push(drawCard());$('card-status').textContent='クラウンはカードを引きました。';return;}
      const c=cpu.splice(idx,1)[0];pile=wild(c)?0:Number(c)||0;
    }
    function play(i){
      const c=player[i];if(c===undefined)return;
      if(!canPlay(c)){$('card-status').textContent='場のカードより大きい数字か、J/Q/K/Aを出してください。';return;}
      player.splice(i,1);pile=wild(c)?0:Number(c)||0;
      if(endRound())return;
      cpuTurn();if(endRound())return;
      render();
    }
    function draw(){
      if(player.some(canPlay)){$('card-status').textContent='出せるカードがあるため、今は引けません。';return;}
      player.push(drawCard());cpuTurn();if(endRound())return;render();
    }
    resetRound();render();
  }
  function showHoodedLetter(){if(g.mode!=='nightmare'||g.hoodedLetterSeen)return;g.hoodedLetterSeen=true;store();showModal(`<h2 class="modal-title">フードの人物からの手紙</h2><div class="document-preview"><div class="classified">PRIVATE / DO NOT COPY</div><p class="modal-note">門番へ。1945年の記録には、ドッペルゲンガーが最初から自然に現れたとは書かれていない。</p><p class="mono" style="font-size:13px;letter-spacing:.14em">20-18-15-25　16-18-15-10-5-3-20</p><p class="modal-note">別紙の見出し：PROJECT TROY<br>責任者：OSWALD D. KEPPLER<br>主任研究者：DR. W. AFTON</p><p class="modal-note">D.D.D.は、何を封じ込めているのだろうか。</p></div><div class="modal-actions"><button class="button" id="hooded-close">手紙をしまう</button></div>`);$('hooded-close').onclick=closeModal;}
  function tutorialPrompt(){if(!isTutorial())return;showModal(`<h2 class="modal-title">Agent #1314 — 研修開始</h2><p class="modal-note">新人門番へ。右の名簿は正確だ。まず顔を照合し、IDと申請書を確認しろ。予定表は参考になるが、載っていないだけで偽物と決めつけるな。必要なら電話を使え。</p><div class="modal-actions"><button class="button" id="tut-begin">研修を開始</button></div>`);$('tut-begin').onclick=closeModal;}
  function customSetup(){if(g.customReady)return;showModal(`<h2 class="modal-title">カスタム住人を作成</h2><p class="modal-note">この勤務に登場する追加住人を設定できます。</p><div class="doc-grid"><label class="doc-field"><small>名前</small><input id="custom-name" placeholder="例：Alex Miller"></label><label class="doc-field"><small>職業</small><input id="custom-job" placeholder="例：郵便配達員"></label><label class="doc-field"><small>部屋番号</small><input id="custom-room" value="F03-04"></label><label class="doc-field"><small>電話番号</small><input id="custom-phone" value="4258"></label><label class="doc-field" style="grid-column:1/-1"><small>外見の特徴</small><input id="custom-features" value="丸顔、短髪"></label></div><div class="modal-actions"><button class="button" id="custom-create">住人を登録して開始</button></div>`);$('custom-create').onclick=()=>{const name=$('custom-name').value.trim();if(name.length<2){notify('名前を入力してください。','wrong');return;}const p={name,id:String(Math.floor(1e11+Math.random()*8e11)),room:$('custom-room').value||'F03-04',phone:$('custom-phone').value||'4258',job:$('custom-job').value||'自営業',roommate:'一人暮らし',features:$('custom-features').value||'丸顔',tags:['roundFace','shortHair']};g.customResidents=[p];NW_DATA.normal.push(p);g.customReady=true;g.visitors=[];closeModal();buildVisitors();renderToday();renderVisitor();store();notify(`${name} を登録しました。`);};}
  function showBriefing(){const headlines=['D.D.D.が各地の不審な帰宅報告を調査中','市内の電話回線に短い雑音が続く','住人は身分証を必ず提示すること','夜間の窓口で奇妙な人物が目撃された','D.D.D.は門番の判断を重視すると発表'];showModal(`<h2 class="modal-title">1955年2月 ${g.day}日 — 朝刊</h2><div class="document-preview"><div class="classified">THE DAILY NEIGHBOR / MORNING EDITION</div><h3 style="font:22px var(--display);margin:10px 0">${headlines[(g.day-1)%headlines.length]}</h3><p class="modal-note">本日も冷え込みが続く見込み。D.D.D.は、住人名簿と提出書類を丁寧に照合するよう通達しています。</p><p class="mono" style="font-size:8px">VOL. 55 / FEBRUARY ${g.day}, 1955</p></div><div class="modal-actions"><button class="button" id="briefing-start">勤務を開始</button></div>`);$('briefing-start').onclick=()=>{closeModal();showClown();if(!g.chesterDone)showChester();};}
  function initGame(){
    if(g.mode==='cards'){startCards();return;}
    if(g.mode==='custom'&&!g.customReady){customSetup();}
    if(!g.visitors?.length)buildVisitors();renderToday();$('visitor-counter').textContent=`来訪者 1 / ${visitorsTarget()}`;renderVisitor();
    if(isTutorial())tutorialPrompt();else if(isCampaign()&&!dailyBriefShown){dailyBriefShown=true;showBriefing();}
    startClock();$('chester-badge').hidden=!Neighbor.getSave().chesterBadge;
    if(isNight()){$('booth-scene').classList.add('nightmare-scene');$('visitor-line').textContent='窓の外は暗く、名簿の文字がわずかに揺れています。';if(!g.hoodedLetterSeen&&rand()<.3)showHoodedLetter();}
    if(g.mode==='tutorial'){$('mode-label').textContent='チュートリアル';$('visitor-line').textContent='Agent #1314：チェックリストを使って4項目を確認してください。';}
  }
  function rankFor(){if(isNight())return g.fatalAdmission||g.entityDeath?'不合格':'合格';if(g.fatalAdmission&&g.kills>0)return 'F';if(g.fatalAdmission)return 'F';if(g.kills>=2)return 'D';if(g.kills===1||g.minorMistakes>=4)return 'C';if(g.minorMistakes>=2)return 'B';if(g.minorMistakes===1)return 'A';return 'S';}
  function campaignEnding(){const stats=g.campaignStats||{};const admitted=new Set(stats.admittedNames||[]),reported=new Set(stats.reportedNames||[]);if((stats.visitorCount||0)>0&&(stats.admittedVisitors||0)===(stats.visitorCount||0))return {title:'6 Feet Under',text:'来訪者をすべて入室させた結果、異常は建物から街へと広がりました。勤務記録はここで途切れています。'};if(reported.size>=20)return {title:'Entitled to One Call',text:'全住人に通報が行われ、アパートは空になりました。D.D.D.はあなたの判断記録を調査し、職務は終了しました。'};if((g.dead||[]).length===1&&g.dead.includes('Dr. W. Afton')&&(stats.humanKilled||0)===1&&(stats.admittedDoppels||0)===0&&(stats.rejectedResidents||0)===0&&(stats.capturedDoppels||0)===(stats.doppelVisitors||0))return {title:'Conspirator',text:'あなたはアフトンだけを通報し、他の住人を守りました。記録は封印されます。'};if((stats.humanKilled||0)===0&&(stats.admittedDoppels||0)===0&&(stats.rejectedResidents||0)===0&&(stats.capturedDoppels||0)===(stats.doppelVisitors||0))return {title:'Employee of the Month',text:'住人をひとりも失わず、現れたドッペルゲンガーをすべて捕獲しました。ヘンリー以来の模範的な勤務です。'};return {title:'Just Like Henry',text:'いくつかの部屋は空になりました。それでも、あなたは5日間の勤務を終えました。'};}
  function finishShift(forcedDeath=false){if(g.finished)return;const elapsed=Date.now()-(g.startedAt||Date.now()),limit=g.timeLimit||visitorsTarget()*60000;if(!forcedDeath&&!g.fatalAdmission&&!g.entityDeath&&!isTutorial()&&elapsed<limit&&!g.timeBonusAwarded){g.score+=10;g.timeBonusAwarded=true;}g.finished=true;if(clockInterval)clearInterval(clockInterval);const rank=rankFor();let dead=forcedDeath||g.fatalAdmission||g.entityDeath;let message=dead?(isNight()?'審査室は異常な存在に支配されました。':'ドッペルゲンガーが侵入し、勤務は失敗に終わりました。'):'勤務は終了しました。記録を確認してください。';if(isTutorial())message='研修は終了しました。4項目の審査手順を確認できました。';const s=Neighbor.getSave();s.records=s.records||[];s.stats=s.stats||{};s.stats.shifts=(s.stats.shifts||0)+1;s.stats.captures=(s.stats.captures||0)+g.captures;s.stats.kills=(s.stats.kills||0)+g.kills;s.stats.admitted=(s.stats.admitted||0)+g.admitted;s.stats.highScore=Math.max(s.stats.highScore||0,g.score);const rankValue={S:6,A:5,B:4,C:3,D:2,F:1};if(rankValue[rank]&&rankValue[rank]>(rankValue[s.stats.highRank]||0))s.stats.highRank=rank;if(g.score>=1000&&!s.achievements.includes('overtime'))s.achievements.push('overtime');if(!s.achievements.includes('first-shift'))s.achievements.push('first-shift');if(rank==='S'&&!s.achievements.includes('clean-day'))s.achievements.push('clean-day');if(s.posters.length>=10&&!s.achievements.includes('collector'))s.achievements.push('collector');if(s.posters.length>=32&&!s.achievements.includes('all-posters'))s.achievements.push('all-posters');if(g.phoneLog?.length&&!s.achievements.includes('double-check'))s.achievements.push('double-check');if(g.reportErrors&&!s.achievements.includes('false-alarm'))s.achievements.push('false-alarm');
    const rec={date:`1955/02/${g.day}`,day:g.day,mode:g.mode,modeLabel:labels[g.mode],rank:rank,score:g.score,captures:g.captures,kills:g.kills,admitted:g.admitted};s.records.push(rec);
    let ending=null,next=false,nextLabel='次の日へ進む';if(isCampaign()){
      s.campaign.dead=[...new Set([...(s.campaign.dead||[]),...(g.dead||[])])];
      if(!dead&&g.day<5){s.campaign.day=g.day;next=true;}
      else if(!dead&&g.day===5){s.campaign.completed=true;s.campaign.unlockedNightmare=true;s.campaign.day=1;next=false;ending=campaignEnding();if(!s.achievements.includes('five-days'))s.achievements.push('five-days');if(!s.achievements.includes('night-shift'))s.achievements.push('night-shift');}
      else{s.campaign.day=1;s.campaign.completed=false;}
    }
    if(g.mode==='tutorial'){next=false;}
    if(isTutorial())s.achievements.push('first-shift');
    Neighbor.setSave(s);const details=(g.actions||[]).map(x=>x.detail);if(g.phoneLog?.length)details.push(...g.phoneLog.map(x=>`電話 ${x.number}：${x.response}`));
    const result={title:isTutorial()?'研修修了':(dead?'勤務失敗':'勤務結果'),rank,captures:g.captures,kills:g.kills,admitted:g.admitted,score:g.score,message,details,next,nextLabel,ending,tutorial:isTutorial(),mode:g.mode,day:g.day};localStorage.setItem(Neighbor.RESULT,JSON.stringify(result));if(dead||!next){Neighbor.writeActive(null);}location.href='/result';
  }
  // UI events
  let dragState=null,dragMoved=false;function attachPaperDrag(el,which){el.dataset.dragX='0';el.dataset.dragY='0';el.addEventListener('pointerdown',e=>{if(el.disabled)return;dragMoved=false;dragState={el,x:e.clientX,y:e.clientY,baseX:Number(el.dataset.dragX||0),baseY:Number(el.dataset.dragY||0),dx:0,dy:0};el.setPointerCapture?.(e.pointerId);});el.addEventListener('pointermove',e=>{if(!dragState||dragState.el!==el)return;const dx=e.clientX-dragState.x,dy=e.clientY-dragState.y;if(Math.abs(dx)+Math.abs(dy)>8)dragMoved=true;dragState.dx=dx;dragState.dy=dy;if(dragMoved){const x=Math.max(-420,Math.min(420,dragState.baseX+dx)),y=Math.max(-260,Math.min(240,dragState.baseY+dy));el.style.transform=`translate(${x}px,${y}px) rotate(${which==='id'?-2:2}deg)`;}});el.addEventListener('pointerup',()=>{if(!dragState||dragState.el!==el)return;const moved=dragMoved;if(moved){el.dataset.dragX=String(Math.max(-420,Math.min(420,dragState.baseX+dragState.dx)));el.dataset.dragY=String(Math.max(-260,Math.min(240,dragState.baseY+dragState.dy)));}dragState=null;if(moved)setTimeout(()=>{dragMoved=false;},250);});el.addEventListener('click',e=>{if(dragMoved){e.preventDefault();e.stopImmediatePropagation();dragMoved=false;return;}showDocument(which);});}attachPaperDrag($('id-document'),'id');attachPaperDrag($('form-document'),'form');document.addEventListener('contextmenu',e=>{if(!$('modal-backdrop').hidden){e.preventDefault();closeModal();}});$('folder-button').onclick=()=>openFolder();$('visitor-face').onclick=askQuestions;$('ask-button').onclick=askQuestions;$('next-line').onclick=()=>{$('visitor-line').textContent=current?.dialog||'……';};
  let dialDragging=false,suppressDialClick=false,lastDialDigit=null;
  function dialDigit(digit){if(phone.replace(/-/g,'').length>=4)return;setPhone(phone.replace(/-+$/,'')+digit);const angle=((Number(digit)||10)-1)*36;$('dial-pointer').style.transform=`translate(-50%,-100%) rotate(${angle}deg)`;}
  $('phone-dial').querySelectorAll('button').forEach(b=>{
    b.addEventListener('pointerdown',()=>{dialDragging=true;suppressDialClick=true;lastDialDigit=b.dataset.digit;dialDigit(lastDialDigit);});
    b.addEventListener('pointerenter',()=>{if(dialDragging&&lastDialDigit!==b.dataset.digit){lastDialDigit=b.dataset.digit;dialDigit(lastDialDigit);}});
    b.addEventListener('click',e=>{if(suppressDialClick){e.preventDefault();suppressDialClick=false;return;}dialDigit(b.dataset.digit);});
  });
  document.addEventListener('pointerup',()=>{dialDragging=false;setTimeout(()=>{suppressDialClick=false;lastDialDigit=null;},0);});
  $('dial-clear').onclick=()=>{setPhone('----');$('dial-pointer').style.transform='translate(-50%,-100%) rotate(0deg)';};$('dial-call').onclick=ringPhone;$('emergency-button').onclick=pressEmergency;
  $('admit-button').onclick=()=>decide('admit');$('reject-button').onclick=()=>decide('reject');$('report-button').onclick=()=>{if(!emergency){notify('緊急ボタンを押してから通報してください。','wrong');return;}if(phone!=='3312'){notify('電話で3312を入力し、発信してください。','wrong');return;}reportVisitor();};
  $('pause-button').onclick=()=>{$('pause-overlay').hidden=false;};$('resume-button').onclick=()=>{$('pause-overlay').hidden=true;};
  // Keyboard support is intentionally optional; all game actions are clickable/tappable.
  initGame();
})();
