const express = require('express');
const path = require('path');
const fs = require('fs');
const crypto = require('crypto');
const bcrypt = require('bcryptjs');

const app = express();
const PORT = process.env.PORT || 3000;
const ROOT = __dirname;
const STORE_PATH = path.join(ROOT, 'data-store.json');
const sessions = new Map();
let pool = null;
let dbReady = false;

app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(express.static(path.join(ROOT, 'public'), { extensions: ['html'] }));

function readStore() {
  try { return JSON.parse(fs.readFileSync(STORE_PATH, 'utf8')); }
  catch { return { accounts: {}, guests: {} }; }
}
function writeStore(store) {
  const tmp = STORE_PATH + '.tmp';
  fs.writeFileSync(tmp, JSON.stringify(store));
  fs.renameSync(tmp, STORE_PATH);
}
async function initDb() {
  if (!process.env.DATABASE_URL) return;
  try {
    const { Pool } = require('pg');
    pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : undefined, max: 4 });
    await pool.query(`CREATE TABLE IF NOT EXISTS neighbor_accounts (
      username VARCHAR(24) PRIMARY KEY,
      password_hash TEXT NOT NULL,
      save_data JSONB NOT NULL DEFAULT '{}'::jsonb,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);
    await pool.query(`CREATE TABLE IF NOT EXISTS neighbor_guests (
      guest_id VARCHAR(80) PRIMARY KEY,
      save_data JSONB NOT NULL DEFAULT '{}'::jsonb,
      updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    )`);
    dbReady = true;
    console.log('PostgreSQL save store ready');
  } catch (err) {
    console.error('PostgreSQL initialization failed; local JSON fallback enabled:', err.message);
    pool = null;
  }
}
function newSession(username) {
  const token = crypto.randomBytes(32).toString('hex');
  sessions.set(token, { username, createdAt: Date.now() });
  return token;
}
function auth(req, res, next) {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  const session = sessions.get(token);
  if (!session) return res.status(401).json({ error: 'ログインが必要です。' });
  req.username = session.username;
  next();
}

app.get('/health', (_req, res) => res.json({ ok: true, database: dbReady ? 'connected' : 'local-fallback' }));

app.post('/api/auth/signup', async (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  if (!/^[A-Za-z0-9_ぁ-んァ-ヶ一-龠ー]{3,24}$/.test(username)) return res.status(400).json({ error: 'ユーザー名は3〜24文字で入力してください。' });
  if (password.length < 8 || password.length > 72) return res.status(400).json({ error: 'パスワードは8〜72文字にしてください。' });
  const hash = await bcrypt.hash(password, 10);
  try {
    if (dbReady) {
      await pool.query('INSERT INTO neighbor_accounts(username,password_hash) VALUES($1,$2)', [username, hash]);
    } else {
      const store = readStore();
      if (store.accounts[username]) return res.status(409).json({ error: 'そのユーザー名はすでに使われています。' });
      store.accounts[username] = { passwordHash: hash, save: {} };
      writeStore(store);
    }
    const token = newSession(username);
    return res.json({ token, username, storage: dbReady ? 'server-db' : 'server-file' });
  } catch (err) {
    if (err.code === '23505') return res.status(409).json({ error: 'そのユーザー名はすでに使われています。' });
    console.error(err);
    return res.status(500).json({ error: 'アカウントを作成できませんでした。' });
  }
});

app.post('/api/auth/login', async (req, res) => {
  const username = String(req.body?.username || '').trim();
  const password = String(req.body?.password || '');
  try {
    let record;
    if (dbReady) {
      const result = await pool.query('SELECT password_hash FROM neighbor_accounts WHERE username=$1', [username]);
      record = result.rows[0] && { passwordHash: result.rows[0].password_hash };
    } else {
      record = readStore().accounts[username];
    }
    if (!record || !(await bcrypt.compare(password, record.passwordHash))) return res.status(401).json({ error: 'ユーザー名またはパスワードが違います。' });
    const token = newSession(username);
    res.json({ token, username, storage: dbReady ? 'server-db' : 'server-file' });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'ログインできませんでした。' });
  }
});

app.post('/api/auth/logout', auth, (req, res) => {
  const token = (req.headers.authorization || '').replace(/^Bearer\s+/i, '');
  sessions.delete(token);
  res.json({ ok: true });
});

app.get('/api/account/save', auth, async (req, res) => {
  try {
    let save = {};
    if (dbReady) {
      const result = await pool.query('SELECT save_data FROM neighbor_accounts WHERE username=$1', [req.username]);
      save = result.rows[0]?.save_data || {};
    } else save = readStore().accounts[req.username]?.save || {};
    res.json({ save });
  } catch (err) { console.error(err); res.status(500).json({ error: 'セーブを読み込めませんでした。' }); }
});

app.put('/api/account/save', auth, async (req, res) => {
  const save = req.body?.save;
  if (!save || typeof save !== 'object' || Array.isArray(save)) return res.status(400).json({ error: 'セーブデータが不正です。' });
  const payload = JSON.stringify(save).slice(0, 500000);
  try {
    if (dbReady) await pool.query('UPDATE neighbor_accounts SET save_data=$1::jsonb, updated_at=NOW() WHERE username=$2', [payload, req.username]);
    else {
      const store = readStore();
      if (!store.accounts[req.username]) return res.status(404).json({ error: 'アカウントが見つかりません。' });
      store.accounts[req.username].save = JSON.parse(payload);
      writeStore(store);
    }
    res.json({ ok: true, savedAt: new Date().toISOString(), storage: dbReady ? 'server-db' : 'server-file' });
  } catch (err) { console.error(err); res.status(500).json({ error: 'セーブを保存できませんでした。' }); }
});

app.get('/api/guest/:id', async (req, res) => {
  if (!/^[a-zA-Z0-9_-]{12,80}$/.test(req.params.id)) return res.status(400).json({ error: 'IDが不正です。' });
  try {
    if (dbReady) {
      const result = await pool.query('SELECT save_data FROM neighbor_guests WHERE guest_id=$1', [req.params.id]);
      return res.json({ save: result.rows[0]?.save_data || {}, storage: 'server-db' });
    }
    return res.json({ save: readStore().guests[req.params.id] || {}, storage: 'server-file' });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'ゲストデータを読み込めませんでした。' }); }
});
app.put('/api/guest/:id', async (req, res) => {
  if (!/^[a-zA-Z0-9_-]{12,80}$/.test(req.params.id)) return res.status(400).json({ error: 'IDが不正です。' });
  const save = req.body?.save;
  if (!save || typeof save !== 'object' || Array.isArray(save)) return res.status(400).json({ error: 'セーブデータが不正です。' });
  const payload = JSON.stringify(save).slice(0, 500000);
  try {
    if (dbReady) {
      await pool.query(`INSERT INTO neighbor_guests(guest_id,save_data,updated_at) VALUES($1,$2::jsonb,NOW())
        ON CONFLICT(guest_id) DO UPDATE SET save_data=EXCLUDED.save_data, updated_at=NOW()`, [req.params.id, payload]);
      return res.json({ ok: true, savedAt: new Date().toISOString(), storage: 'server-db' });
    }
    const store = readStore();
    store.guests[req.params.id] = JSON.parse(payload);
    writeStore(store);
    return res.json({ ok: true, savedAt: new Date().toISOString(), storage: 'server-file' });
  } catch (err) { console.error(err); return res.status(500).json({ error: 'ゲストデータを保存できませんでした。' }); }
});

app.get('/', (_req, res) => res.sendFile(path.join(ROOT, 'public', 'index.html')));
app.get('/play', (_req, res) => res.sendFile(path.join(ROOT, 'public', 'play.html')));
app.get('/how-to', (_req, res) => res.sendFile(path.join(ROOT, 'public', 'how-to.html')));
app.get('/records', (_req, res) => res.sendFile(path.join(ROOT, 'public', 'records.html')));
app.get('/result', (_req, res) => res.sendFile(path.join(ROOT, 'public', 'result.html')));

initDb().finally(() => app.listen(PORT, () => console.log(`Neighbor Watch listening on ${PORT}`)));
